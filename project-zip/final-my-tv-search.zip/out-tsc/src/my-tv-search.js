import { MyTvSearch } from './MyTvSearch.js';
customElements.define('my-tv-search', MyTvSearch);
//# sourceMappingURL=my-tv-search.js.map