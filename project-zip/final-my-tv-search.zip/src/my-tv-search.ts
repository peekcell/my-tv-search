import { MyTvSearch } from './MyTvSearch.js';

customElements.define('my-tv-search', MyTvSearch);
